BONGREN JUNIOR WEBSITE

Files:
- index.html
- images/bongren-hero.webp
- images/bongren-profile.webp

How to view:
1. Open index.html in Google Chrome.
2. To publish it online, upload the whole folder to a web hosting service.

IMPORTANT:
Because Bongren Junior is a minor, the public version intentionally does not display the supplied phone number or personal email address. A parent/guardian should approve any personal contact details before they are published online.

TikTok:
https://www.tiktok.com/@humbletiger50
